<?php

FFI::load(__DIR__ . '/bug78761_preload.h');
