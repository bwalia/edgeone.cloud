#!/bin/bash
sudo service redis_6379 stop

