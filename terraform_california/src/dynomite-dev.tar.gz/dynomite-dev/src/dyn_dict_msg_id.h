#include "dyn_dict.h"

extern dictType msg_table_dict_type;
