/*
 * Dynomite - A thin, distributed replication layer for multi non-distributed
 * storages. Copyright (C) 2015 Netflix, Inc.
 *
 * author: Ioannis Papapanagiotou
 */

char *ascii_logo =
    "                                                                      \n"
    "     #                                \      m                        \n"
    "  mmm#  m   m  mmmm    mmm   mmmmm  mmm    mm#mm   mmm                \n"
    " #   #  \\m m/  #   #  #   #  # # #    #      #    #   #               \n"
    " #   #   #m#   #   #  #   #  # # #    #      #    #''''               \n"
    " \\#m##   \\#    #   #   #m#   # # #  mm#mm    mm    #mm                \n"
    "         m/\n"
    "        ##\n";
//"                                                                      \n\n";
