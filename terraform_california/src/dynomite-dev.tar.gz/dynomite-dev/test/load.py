#!/usr/bin/env python3

##
# A very simple basic program that will load data in a dynomite/redis server.
##
import argparse
import redis

if __name__ == '__main__':
    
